"""
Dataset 1 (SNIES matriculados 2016-2025) desde el servicio REST del portal.
SE EJECUTA EN TU COMPUTADOR o en Colab:   python descargar_snies_v2.py

Hace 10 peticiones (una por año; cada una trae todos los departamentos), guarda el JSON crudo en
json_snies/ y genera dataset1_lleno.csv con las columnas:
    departamento, año, tecnica, tecnologica, universitaria, oficial, privado
(el mismo formato que lee Tarea1_Dataset.ipynb).
Requiere: pip install requests pandas
"""
import json, time, pathlib, unicodedata, re, sys
import requests
import pandas as pd

BASE = "https://hecaa.mineducacion.gov.co/consultaspublicas/rest/poblacionales/datoscategoria"
AÑOS = list(range(2016, 2026))

# id del portal -> nombre. Los ids son SUPOSICIONES (ISO 3166-2:CO); el script avisa los que no reconozca.
DEPARTAMENTOS = {
    "CO-AMA": "Amazonas", "CO-ANT": "Antioquia", "CO-ARA": "Arauca", "CO-ATL": "Atlántico",
    "CO-DC": "Bogotá D. C.", "CO-BOL": "Bolívar", "CO-BOY": "Boyacá", "CO-CAL": "Caldas",
    "CO-CAQ": "Caquetá", "CO-CAS": "Casanare", "CO-CAU": "Cauca", "CO-CES": "Cesar",
    "CO-CHO": "Chocó", "CO-COR": "Córdoba", "CO-CUN": "Cundinamarca", "CO-GUA": "Guainía",
    "CO-GUV": "Guaviare", "CO-HUI": "Huila", "CO-LAG": "La Guajira", "CO-MAG": "Magdalena",
    "CO-MET": "Meta", "CO-NAR": "Nariño", "CO-NSA": "Norte de Santander", "CO-PUT": "Putumayo",
    "CO-QUI": "Quindío", "CO-RIS": "Risaralda", "CO-SAP": "San Andrés y Providencia",
    "CO-SAN": "Santander", "CO-SUC": "Sucre", "CO-TOL": "Tolima", "CO-VAC": "Valle del Cauca",
    "CO-VAU": "Vaupés", "CO-VID": "Vichada",
}

# Mismos nombres de nivel que usa el propio portal (poblacional.js) para ordenar la tabla.
NIVELES = {
    "tecnica": {"formacion tecnico profesional", "formacion tecnica profesional",
                "tecnico profesional", "tecnica profesional"},
    "tecnologica": {"tecnologo", "tecnologica", "tecnologico"},
    "universitaria": {"universitario", "universitaria"},
}

def normalizar(s):
    s = unicodedata.normalize("NFD", str(s))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn").lower()
    return re.sub(r"[^a-z ]", "", s).strip()

def descargar(año, carpeta):
    destino = carpeta / f"datoscategoria_{año}.json"
    if destino.exists() and destino.stat().st_size > 100:
        return json.loads(destino.read_text(encoding="utf-8"))
    params = dict(variable="MATRICULADO", anio=año, semestre=0, acreditada=0)
    for intento in range(3):
        try:
            r = requests.get(BASE, params=params, timeout=60,
                             headers={"User-Agent": "Mozilla/5.0 (proyecto academico PDS)",
                                      "Accept": "application/json"})
            r.raise_for_status()
            data = r.json()
            destino.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            return data
        except Exception as e:
            print(f"  intento {intento+1} falló para {año}: {e}")
            time.sleep(3)
    raise SystemExit(f"No se pudo descargar {año}")

def parsear(data, año, vistos):
    """Convierte la respuesta de un año en filas del dataset."""
    filas = []
    for item in data["datos"]:
        did = item["departamento"]
        if did == "COL":                      # total nacional
            continue
        niv = {k: None for k in NIVELES}
        sector = {}
        for cat in item.get("categorias", []):
            if cat["categoria"] == "NIVEL":
                for v in cat["valores"]:
                    nombre = normalizar(v["category"]); vistos["nivel"].add(v["category"])
                    for col, nombres in NIVELES.items():
                        if nombre in nombres:
                            niv[col] = (niv[col] or 0) + int(float(v["total"]))
            elif cat["categoria"] == "ORIGEN":
                for v in cat["valores"]:
                    vistos["origen"].add(v["category"])
                    sector[normalizar(v["category"])] = float(v["total"])
        total_sector = sum(sector.values())
        pct = (lambda k: round(100 * sector.get(k, 0) / total_sector, 1)) if total_sector else (lambda k: None)
        filas.append(dict(id=did, departamento=DEPARTAMENTOS.get(did), año=año,
                          tecnica=niv["tecnica"], tecnologica=niv["tecnologica"],
                          universitaria=niv["universitaria"],
                          oficial=pct("oficial"), privado=pct("privado")))
    return filas

def main():
    carpeta = pathlib.Path("json_snies"); carpeta.mkdir(exist_ok=True)
    vistos = {"nivel": set(), "origen": set()}
    filas = []
    for año in AÑOS:
        data = descargar(año, carpeta)
        filas += parsear(data, año, vistos)
        print("ok", año); time.sleep(1)

    df = pd.DataFrame(filas)
    print("\nCategorías de NIVEL vistas:", sorted(vistos["nivel"]))
    print("Categorías de SECTOR vistas:", sorted(vistos["origen"]))
    sin_nombre = sorted(df.loc[df["departamento"].isna(), "id"].unique())
    print("\nIds del portal SIN nombre asignado (corregir en DEPARTAMENTOS):", sin_nombre or "ninguno")

    df = df.dropna(subset=["departamento"])
    out = df[["departamento", "año", "tecnica", "tecnologica", "universitaria", "oficial", "privado"]]
    out = out.sort_values(["departamento", "año"]).reset_index(drop=True)
    out.to_csv("dataset1_lleno.csv", index=False, encoding="utf-8")
    print("\nFilas:", len(out), "(esperado 330) | territorios:", out["departamento"].nunique(), "(esperado 33)")
    print("Faltantes por columna:\n", out.isna().sum())

if __name__ == "__main__":
    main()
