# Proyecto PDS: Análisis de señales temporales de matrícula en educación superior en Colombia (2016–2025)

Curso: Procesamiento Digital de Señales — Universidad Militar Nueva Granada
Integrantes: _(completar con los nombres del equipo)_

## Estado de entregas

| Entrega | Contenido | Estado |
|---|---|---|
| Primera (10 de noviembre de 2026) | Tarea 1: construcción del Dataset 1 | Entregada |
| Segunda (24 de noviembre de 2026) | Tareas 2, 3, 4 y 5 | Entregada en esta versión |

## Contenido del repositorio

| Archivo | Descripción |
|---|---|
| `Proyecto_PDS_Tareas_1_a_5.ipynb` | Notebook organizado por tareas, ejecutado, con código, explicaciones, gráficas y análisis |
| `descargar_snies_v2.py` | Obtiene los datos del servicio del SNIES y genera `dataset1_lleno.csv` |
| `dataset1_lleno.csv` | Salida del script; entrada del notebook |
| `dataset1.csv` | **Dataset 1**: 330 filas (33 territorios × 10 años) × 7 columnas |
| `dataset2.csv` | **Dataset 2**: crecimiento interanual por departamento y nivel (93 filas × 11 columnas) |
| `dataset3.csv` | **Dataset 3**: variación de la participación oficial en pp (33 filas × 10 columnas) |
| `dataset2_estimados.csv`, `dataset2_exclusiones.csv` | Tasas estimadas (10) y filas excluidas (6) por divisiones por cero |
| `faltantes_tecnica_documentados.csv` | Celdas de `tecnica` sin dato en la fuente, tratadas como 0 |
| `asignacion_grupos.csv` | Grupo asignado a cada departamento en los cuatro agrupamientos |
| `contexto_territorial.csv` | Región, PIB 2024 y pobreza monetaria 2024 usados para interpretar los grupos |
| `tarea5_tabla_comparativa.csv` | Pares que superan su promedio histórico en ambos intervalos posteriores a 2023 |
| `figuras/` | Figuras 1 a 9 |

## Fuentes de los datos

- **SNIES – Ministerio de Educación Nacional**, consultas públicas de *Matriculados*, dato estadístico anual 2016–2025 (`hecaa.mineducacion.gov.co/consultaspublicas`). Se obtuvo del servicio que alimenta el portal (`rest/poblacionales/datoscategoria`), con una petición por año.
- **DANE**, PIB departamental 2024p y pobreza monetaria departamental 2024 (contexto de la Tarea 4).
- **Ley 2307 de 2023** (Función Pública) y política de gratuidad del MEN (contexto de la Tarea 5).

## Cómo reproducir

1. `pip install requests pandas numpy matplotlib scikit-learn`
2. `python descargar_snies_v2.py` → genera `dataset1_lleno.csv` y la carpeta `json_snies/`.
3. Abrir `Proyecto_PDS_Tareas_1_a_5.ipynb` en la misma carpeta y ejecutar todas las celdas. Genera los datasets 1, 2 y 3, los archivos auxiliares y las figuras.

## Decisiones metodológicas

**Tarea 1.** Los porcentajes oficial/privado se calcularon como cociente de totales por sector (suman 100). Los nombres de nivel cambian en 2021 ("Tecnológica/Tecnológico", "Universitaria/Universitario") y se tratan como el mismo nivel. Los 60 valores vacíos de `tecnica` (el servicio omite categorías sin estudiantes) se interpretan como 0 matriculados y se documentan.

**Tarea 2.** Se aplica la regla de la guía: exclusión de filas con más de dos divisiones por cero **antes** de estimar (6 filas, todas de técnica profesional) y estimación con el promedio de las tasas válidas adyacentes (10 tasas, identificadas). Las estimaciones pueden producir valores extremos (p. ej. Cauca 2022–2023: +5 900 %).

**Tarea 3.** Selección por el promedio de las nueve tasas, entre filas **sin valores estimados**; se reporta también la mediana como control de robustez.

**Tarea 4.** Transformación arcsinh (escala 10 % para tasas, 5 pp para el sector oficial), K-means con distancia euclidiana, detección de atípicos por distancia al 3.er vecino (regla de Tukey), k entre 2 y 6 por coeficiente de silueta con grupos de al menos 3 departamentos, y validación contra Ward (ARI) y PCA. Las siluetas son bajas o moderadas (0,16–0,49): los grupos son descriptivos.

**Tarea 5.** Referente histórico = media de las siete primeras tasas, tal como indica la guía. Se añaden dos controles fuera de la guía: sensibilidad con la mediana y comparación con ventanas anteriores.

## Alcance e interpretación

Se distingue entre hechos observados, interpretaciones e hipótesis por verificar. Los resultados de la Tarea 5 muestran que cerca de la mitad de los pares departamento–nivel superan su promedio histórico después de 2023, pero **no permiten establecer que el aumento se deba a la Ley 2307 de 2023**.

## Uso de herramientas de IA

Se utilizó inteligencia artificial como apoyo para la programación (scripts y notebook). Las decisiones metodológicas, la evaluación de resultados y las conclusiones son del equipo.
